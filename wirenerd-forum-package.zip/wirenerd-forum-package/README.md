# WireNerd — Community System (Forum + Profiles + Notifications)

This package contains every file for the community features added to wirenerd.com:
the forum, public member profiles, the account-page additions, the reply-notification
system, and the shared notification bell — plus the database setup.

Your full website (all lesson/guide/component pages) is **not** in this zip — that lives
in your GitHub repo `wirenerdelectrician/wirenerd`, which is already a complete backup.
This package is the community layer that sits on top of it.

---

## Files in this package

| File | What it is | Where it goes |
|------|-----------|---------------|
| `forum.html` | The forum: section index, posts, replies, image upload, its own notification bell | repo root → `/forum.html` |
| `member.html` | Public read-only profile (photo, bio, that person's posts). Forum author names link here | repo root → `/member.html` |
| `profile.html` | Your "My Account" page — now also has profile photo upload, description (bio), and a Notifications list | repo root → `/profile.html` (replaces the old one) |
| `wn-notify.js` | Shared notification bell. One script, included on every page so the 🔔 shows site-wide | repo root → `/wn-notify.js` |
| `supabase-forum-setup.sql` | Creates the forum tables, security rules, and image storage buckets | run once in Supabase SQL Editor |
| `supabase-notifications.sql` | Creates the notifications table, the auto-notify trigger, and realtime | run once in Supabase SQL Editor |

---

## Supabase project (the backend)

- **Project ref:** `ntlfuexiilxydnpuqhhv`
- **URL:** `https://ntlfuexiilxydnpuqhhv.supabase.co`
- **Publishable (anon) key:** `sb_publishable_OWZrMSaAkonwYjfTrYpuyg_xn_Gy-eG`
  - This key is **public and safe** to keep in the HTML/JS — it only allows what the
    Row-Level-Security (RLS) rules permit. It is NOT a secret. (Never put the *service role*
    or any `sk_...` secret key in front-end files.)

### Tables
- `profiles` — `id` (= auth user id), `display_name`, `bio`, `avatar_url`, `created_at`.
  A trigger auto-creates a row when someone signs up.
- `forum_posts` — `id`, `user_id`, `category`, `title`, `body`, `image_url`, `created_at`.
- `forum_replies` — `id`, `post_id`, `user_id`, `body`, `image_url`, `created_at`.
- `notifications` — `id`, `user_id` (recipient), `actor_name`, `type`, `post_id`,
  `post_title`, `read`, `created_at`.

### Storage buckets (public read)
- `avatars` — profile photos. Path pattern: `<userid>/avatar-<timestamp>.<ext>`
- `post-images` — pictures attached to posts/replies. Path: `<userid>/<timestamp>-<rand>.<ext>`

### Security model (RLS)
- Anyone can **read** posts, replies, and profiles (the forum is public to read).
- A signed-in user can only **write/edit/delete their own** posts, replies, and profile.
- Storage: anyone can view images; a user can only upload into their own `<userid>/` folder.
- Notifications: you can only read/update your **own** notifications. They are created
  automatically by the DB trigger (`notify_post_author`) when someone replies to your post —
  the front-end never inserts them directly.

### Categories (forum sections)
Defined in `forum.html` in the `CATEGORIES` array: Homework Help, General Q&A,
Jobs & Trade Talk, Gear & Tools. Edit that array to add/rename sections.

---

## How auth ties together
All pages use the same Supabase project, so a sign-in on any page (account/forum) is
shared across the whole site (the session is stored in the browser). The forum's
"＋ New post"/reply buttons open a sign-in box when needed; the account page handles
sign-out.

---

## Deploy workflow
The site is static and auto-deploys on every push to GitHub (Vercel watches `main`).

Re-deploy one or more pages:
```
cd ~/Desktop/wirenerd
cp ~/Downloads/forum.html ./forum.html        # copy in whatever you changed
git add -A && git commit -m "update" && git push
```

---

## First-time setup (already done — here for reference / disaster recovery)
1. Run `supabase-forum-setup.sql` in Supabase → SQL Editor.
2. Run `supabase-notifications.sql` in Supabase → SQL Editor.
3. (Optional) Supabase → Authentication → Sign In / Providers → Email → turn
   **Confirm email** off for instant sign-ups.
4. Deploy `forum.html`, `member.html`, `profile.html`, `wn-notify.js`.

---

## Site-wide one-liners we used (safe to re-run; each skips files already done)

Add the **Forum** tab to every page's nav:
```
cd ~/Desktop/wirenerd && for f in *.html; do grep -q 'href="/forum.html"' "$f" || perl -0777 -i -pe 's{(<a href="/classes\.html">Classes</a>)}{$1<a href="/forum.html">Forum</a>}' "$f"; done
```

Keep the nav on one clean line (alignment fix):
```
cd ~/Desktop/wirenerd && export CSS='<style id="wn-navfix">header .wrap{max-width:1200px;margin:0 auto;display:flex;align-items:center;justify-content:space-between;gap:18px}header .brand{flex:none}header nav{display:flex;flex-wrap:wrap;align-items:center;justify-content:flex-end;row-gap:8px}header nav a{margin-left:22px;white-space:nowrap}@media(max-width:780px){header .wrap{flex-direction:column;align-items:flex-start;gap:10px}header nav{justify-content:flex-start}header nav a{margin-left:0;margin-right:16px}}</style>' && for f in *.html; do grep -q 'wn-navfix' "$f" || perl -0777 -i -pe 's{</head>}{$ENV{CSS}\n</head>}' "$f"; done
```

Add the notification bell to every page (skips forum.html, which has its own):
```
cd ~/Desktop/wirenerd && cp ~/Downloads/wn-notify.js ./wn-notify.js && for f in *.html; do [ "$f" = "forum.html" ] && continue; grep -q 'wn-notify.js' "$f" || perl -0777 -i -pe 's{</body>}{<script defer src="/wn-notify.js"></script>\n</body>}' "$f"; done
```

---

## Fixing common things

**Forum loads but is empty / "permission" or RLS error in the console**
→ Re-run `supabase-forum-setup.sql` (it's safe to re-run). Make sure you're on the right project.

**Images won't upload**
→ The `avatars` / `post-images` buckets or their policies are missing. Re-run
`supabase-forum-setup.sql` (it creates/repairs them).

**The 🔔 bell doesn't appear**
→ You must be **signed in** (the bell is hidden for logged-out visitors by design).
Also confirm the page includes `<script defer src="/wn-notify.js"></script>` and that
`supabase-notifications.sql` has been run.

**Bell shows but never gets a count**
→ Reply notifications come from the DB trigger. Re-run `supabase-notifications.sql`.
Replying to *your own* post does **not** notify you (by design).

**Nav wraps to two lines / looks misaligned on some page**
→ That page is missing the `wn-navfix` style. Re-run the alignment one-liner above.

**A page is missing the Forum tab**
→ Its nav didn't match the pattern. Re-run the "Add Forum tab" one-liner, or add
`<a href="/forum.html">Forum</a>` into that page's `<nav>` by hand.

**Change the forum colors/theme**
→ Edit the `:root{ ... }` CSS variables at the top of `forum.html` / `member.html`.

**Moderate / delete a post as the owner**
→ Use the Supabase dashboard → Table Editor → `forum_posts` / `forum_replies` → delete the row.

---

## Future: email and mobile push
The `notifications` table is the foundation. To email people when they're off-site,
add a Supabase Edge Function + a mail provider (e.g. Resend) triggered on new notification
rows. A future mobile app can reuse this exact backend (Supabase has iOS/Android SDKs) and
add native push (APNs/FCM) on top of the same notification rows.

---
_Backend project: ntlfuexiilxydnpuqhhv · Generated as a reference snapshot._
